
csu_trend_legend <-
	function(title=NULL, position="bottom",nrow=1, right_space_margin=1) {
  
  structure(list(title = title, position = position,
                 nrow = nrow, 
                 right_space_margin = right_space_margin)) 
}

