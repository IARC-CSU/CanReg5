library(testthat)
test_check("Rcan")
