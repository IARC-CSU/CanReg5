.onAttach <- function(libname = find.package("Rcan"), pkgname = "Rcan") {
  packageStartupMessage("Rcan 1.3.1, for help type ?Rcan. type example(Rcan) to see demo of the function.")
  
}